import express from 'express';
import {responseUtils} from "../utils/responseUtils.js";
import {selectDictionary} from "../service/Dictionary.js";
const router = express.Router();
//查询字典
router.get('/:word', (req, res) => {
    res.send(responseUtils.success(selectDictionary(req.params.word || '')));
})
export default router;