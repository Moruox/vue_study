import {user_info} from "../db/user_info.js"
import {page} from "../utils/page.js";
import {v4 as uuidv4} from "uuid";
export const selectUserInfo = (currentPage, pageSize)=>{
     return page(user_info, currentPage, pageSize)
}

export const insertUserInfo = (userInfo)=>{
    const {userName,age,gender,email,password,address,postCode} = userInfo
    const userInfoDao = {
        id: uuidv4(),
        userName:userName || "",
        age:age || 0,
        gender:gender || "",
        email:email.trim() || "",
        password:password || "123456",
        address:address || "",
        postCode:postCode || "700000",
    }
    user_info.push(userInfoDao)
    return null
}

export const updateUserInfo = (userInfo)=>{
    const {id,userName,age,gender,email,password,address,postCode} = userInfo
    const index = user_info.findIndex(item=>item.id===id)
    if(index>=0){
        user_info[index] = {
            id,
            userName:userName || "",
            age:age || 0,
            gender:gender || "",
            email:email.trim() || "",
            password:password || "123456",
            address:address || "",
            postCode:postCode || "700000",
        }
        return null
    }
    return "用户不存在"
}

export const deleteUserInfo = (id)=>{
    const index = user_info.findIndex(item=>item.id===id)
    if(index>=0){
        user_info.splice(index,1)
        return null
    }
    return "用户不存在"
}

