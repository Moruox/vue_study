import dictionary from '../db/dictionary.js';
export const selectDictionary = (word) => {
    return dictionary[word] || [];
}