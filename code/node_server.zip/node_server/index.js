import express from 'express';
import userController from './controller/UserInfo.js';
import DictionaryController from './controller/Dictionary.js';
const app = express();
//中间间,处理请求和响应
app.use(express.json());
app.get('/',(req,res)=>{
    res.send('server is running on port 3000,please access /users');
})
app.use('/userinfo', userController);
app.use('/select_dictionary', DictionaryController);
//监听端口
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});