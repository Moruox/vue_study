export const responseUtils ={
    success:(data)=>({code:200,data,message:'操作成功!'}),
    error:(message)=>({code:500,data:null,message:message}),
    warning:(message)=>({code:210,data:null,message:message}),
}