//分页函数
export const page = (dataList, cp, ps) => {
    let currentPage = parseInt(cp);
    let pageSize = parseInt(ps);
    // 验证输入参数
    if (!Array.isArray(dataList)) {
        throw new Error("dataList 必须是一个数组");
    }
    if (currentPage <= 0 ) {
        throw new Error("currentPage 必须是一个大于0 最小是 1 的数字");
    }
    if (pageSize <= 0) {
        throw new Error("pageSize 必须是一个大于等于 0 的数字");
    }

    // 计算分页起始索引和结束索引
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;

    // 截取当前页的数据
    const paginatedData = dataList.slice(startIndex, endIndex);

    // 返回分页结果
    return {
        currentPage,                   // 当前页码
        pageSize,                      // 每页大小
        total: dataList.length,   // 数据总条数
        totalPages: Math.ceil(dataList.length / pageSize), // 总页数
        list: paginatedData            // 当前页数据
    };
};
