### 安装依赖
```bash
pnpm i 
```
### 启动服务
```bash
pnpm run dev
```