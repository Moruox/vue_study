export const post_dictionary = [
    { value: "100000", label: "总经理" },
    { value: "200000", label: "副总经理" },
    { value: "300000", label: "组长" },
    { value: "400000", label: "副组长" },
    { value: "500000", label: "经理" },
    { value: "600000", label: "副经理" },
    { value: "700000", label: "员工" }
]
export const gender_dictionary = [
    { value: "1", label: "男" },
    { value: "0", label: "女" }
]
export default {
   post:post_dictionary,
   gender:gender_dictionary
}