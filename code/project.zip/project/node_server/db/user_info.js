import { v4 as uuidv4 } from 'uuid';
export const user_info = [
    {
        id: uuidv4(),
        userName: "David",
        age: 20,
        gender: "1",
        email: "david@gmail.com",
        password: "123456",
        address: "Amsterdam 1011 JA",
        postCode: "100000"
    },
    {
        id: uuidv4(),
        userName: "John",
        age: 25,
        gender: "1",
        email: "john@gmail.com",
        password: "123456",
        address: "New York 10001 US",
        postCode: "200000"
    },
    {
        id: uuidv4(),
        userName: "Aiman",
        age: 20,
        gender: "0",
        email: "sarah@gmail.com",
        password: "123456",
        address: "Amsterdam 1011 JA",
        postCode: "200000"
    },
    {
        id: uuidv4(),
        userName: "Tom",
        age: 25,
        gender: "1",
        email: "john@gmail.com",
        password: "123456",
        address: "New York 10001 US",
        postCode: "300000"
    },
    {
        id: uuidv4(),
        userName: "Jane",
        age: 20,
        gender: "0",
        email: "sarah@gmail.com",
        password: "123456",
        address: "Amsterdam 1011 JA",
    },
    {
        id: uuidv4(),
        userName: "TomBoy",
        age: 25,
        gender: "1",
        email: "john@gmail.com",
        password: "123456",
        address: "New York 10001 US",
    },
    {
        id: uuidv4(),
        userName: "SarahBoy",
        age: 20,
        gender: "1",
        email: "sarah@gmail.com",
        password: "123456",
        address: "Amsterdam 1011 JA",
    },
    {
        id: uuidv4(),
        userName: "TomGirl",
        age: 25,
        gender: "0",
        email: "john@gmail.com",
        password: "123456",
        address: "New York 10001 US",
    }
]