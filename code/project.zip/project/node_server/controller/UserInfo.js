import express from 'express';
import {responseUtils} from "../utils/responseUtils.js";
import {deleteUserInfo, insertUserInfo, selectUserInfo, updateUserInfo} from "../service/UserInfo.js";
const router = express.Router();
//查询全部用户信息
router.get("/select/:currentPage/:pageSize",(req,res)=>{
    const {currentPage,pageSize} = req.params
    res.send(responseUtils.success(selectUserInfo(currentPage,pageSize)))
})
//新增用户信息
router.post("/insert",(req,res)=>{
    res.send(responseUtils.success(insertUserInfo(req.body)))
})

//删除用户信息
router.delete("/delete/:id",(req,res)=>{
    const {id} = req.params
    res.send(responseUtils.success(deleteUserInfo(id)))
})

//修改用户信息
router.put("/update",(req,res)=>{
    res.send(responseUtils.success(updateUserInfo(req.body)))
})

export default router