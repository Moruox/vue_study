import {
    deleteMessage,
    insetMessage,
    selectAll, type TodoType,
    updateMessage,
} from "../db";

type responseType<T = any> = {
    code: number;
    data: T;
    message: string;
}
//模拟axios
export const axios = {
    get: (data:T):responseType<T>=>data,
    post: (data:T):responseType<boolean>=>data,
    put: (data:T):responseType<boolean>=>data,
    delete: (data:T):responseType<boolean>=>data,
}

//查询全部数据源的方法
export const selectAllMessageApi = (page?:number, pageSize?:number)=>axios.get<TodoType[]>(selectAll(page, pageSize));

//新增数据源的方法
export const insertMessageApi = (MessageListOrMsg:Array<TodoType> | TodoType)=>axios.post<Response<boolean>>(insetMessage(MessageListOrMsg));

//更新数据源的方法
export const updateMessageApi = (MessageListOrMsg:TodoType)=>axios.put<boolean>(updateMessage(MessageListOrMsg));

//删除数据源的方法
export const deleteMessageApi = (id:number)=>axios.delete<boolean>(deleteMessage(id));