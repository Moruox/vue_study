//用户的类型
export  type  User =  {
    id: string;
    userName: string;
    age: number;
    gender: "1" | "0"; // 性别值仅能为 "1" 或 "0"
    email: string;
    password: string;
    address: string;
    postCode: string;
}
//分页类型
export type Page<T> = {
    currentPage: number;
    pageSize: number;
    total: number;
    list: T[];
}
//字典通用类型
export type DictListType = {
    label: string;
    value: string;
}[]