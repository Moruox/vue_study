import axios from 'axios';
import {ElMessageBox} from "element-plus";
const api = axios.create({
    baseURL: '/api',//将全部请求的前缀都加上/api便于vite转发
    timeout: 5000,//超时时间
    headers: {
        'Content-Type': 'application/json',//默认请求头
    }
});
type responseType<T> = {
    code: number;
    data: T;
    message: string;
}
//请求响应拦截器
api.interceptors.response.use((response)=>{
    //对响应数据做处理
    if(response.data && response.data.code === 200) {
        return response.data;
    }
},async (error)=>{
    //请求错误时做一些处理
   await ElMessageBox({
        message: error.message,
        type: 'error',
        title: '请求错误',
    })
})
//统一封装axios请求方法风格
const axiosApi = {
    get:<T>(url,data,config)=> api.get<any,responseType<T>>(url,{...config,params:data || {}}),
    post:<T>(url,data,config)=> api.post<any,responseType<T>>(url,data,config),
    put:<T>(url,data,config)=> api.put<any,responseType<T>>(url,data,config),
    delete:<T>(url,data,config)=> api.delete<any,responseType<T>>(url,{...config,data}),
}
export default axiosApi; //对外暴露接口