import axiosApi from "../index.ts"
import type {DictListType, Page, User} from "../type";
import {reactive, ref} from "vue";
//查询用户列表
export const getUserListApi = (params: {currentPage: number, pageSize: number}) => {
    return axiosApi.get<Page<User>>(`/userinfo/select/${params.currentPage}/${params.pageSize}`)
}
//新增用户
export const addUserApi = (user:User) => {
    return axiosApi.post<null>('/userinfo/insert', user)
}
//修改用户
export const updateUserApi = (user:User) => {
    return axiosApi.put<null>(`/userinfo/update`, user)
}
//删除用户
export const deleteUserApi = (userId:string) => {
    return axiosApi.delete<null>(`/userinfo/delete/${userId}`)
}
//获取字典的接口
export const getGenderDictApi = (...word:string[]) => {
    const dictMap:Record<string, DictListType[]> = {
    }
    word.forEach(key => {
        dictMap[key] = ref<DictListType[]>([])
        //分批请求字典数据
        axiosApi.get<DictListType[]>(`/select_dictionary/${key}`).then(res => {
          dictMap[key] = dictMap[key].value = res.data
        })
    })
    return  dictMap
}