<template>
  <user />
</template>
<script lang="ts" setup>
import user from './page/user/index.vue';
</script>
