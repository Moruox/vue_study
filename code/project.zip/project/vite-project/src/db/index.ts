//user接口
import {generateId} from "../utils/generateId.ts";

export type TodoType = {
    id: string;
    message: string;
    edit: boolean;
}
//分页接口
export type Page<T> = {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
    list: T[];
}
//响应接口
type responseType<T = any> = {
    code: number;
    data: T;
    message: string;
}
//模拟数据库
export const db:Array<TodoType> = [
    {
        id: generateId(),
        message: '模拟消息1',
        edit: false
    },
    {
        id: generateId(),
        message: '模拟消息2',
        edit: false
    },
    {
        id: generateId(),
        message: '模拟消息3',
        edit: false
    },
    {
        id: generateId(),
        message: '模拟消息4',
        edit: false
    },
    {
        id: generateId(),
        message: '模拟消息5',
        edit: false
    },
    {
        id: generateId(),
        message: '模拟消息6',
        edit: false
    }
]
//将返回的结果包装

const success = <T>(data: T): responseType<T> => {
    return {
        code: 200,
        data,
        message: 'success'
    }
}

//获取全部数据
export const selectAll = (page=1, pageSize=999999):responseType<Page<TodoType>> => {
    const startIndex = (page - 1) * pageSize; // 计算起始索引
    const endIndex = startIndex + pageSize;   // 计算结束索引
    const total = db.length;                  // 数据总量
    const data = db.slice(startIndex, endIndex); // 获取分页数据
    return success({
        total,         // 总数据量
        page,          // 当前页码
        pageSize,      // 每页数量
        totalPages: Math.ceil(total / pageSize), // 总页数
        list: data,           // 当前页的数据
    })
};

export const insetMessage = (todoListOrTodo: Array<TodoType> | TodoType) =>{
    if(Array.isArray(todoListOrTodo)){
        todoListOrTodo.forEach(todo => db.push({...todo, id: generateId()}))
        return success( true);
    }else {
        db.push({...todoListOrTodo, id: generateId()});
        return success( true);
    }
}

export const deleteMessage = (id: string):boolean => {
    const index = db.findIndex(todo => todo.id === id);
    if (index === -1) {
        return success(false);
    }
    db.splice(index, 1);
    return success(true);
}

export const updateMessage = (todoListOrTodo: Array<TodoType> | TodoType):boolean => {
    if(Array.isArray(todoListOrTodo)){
        todoListOrTodo.forEach(todo => {
            const index = db.findIndex(item => item.id === todo.id);
            if(index !== -1){
                db[index] = {...todo, id: todo.id};
            }
        })
        return success(true);
    }else {
        const index = db.findIndex(item => item.id === todoListOrTodo.id);
        if(index !== -1){
            db[index] = {...todoListOrTodo, id: todoListOrTodo.id};
            return success(true);
        }
        return success(false);
    }
}