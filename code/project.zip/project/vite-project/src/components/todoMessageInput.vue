<template>
  <!--作为新增待办事项的输入框-->
  <div class="todo-msg">
    <!-- 输入框 当数据发生变化时，触发update:modelValue事件 通知父组件更新数据 -->
    <input class="todo-input" :value="modelValue" @input="$emit('update:modelValue', $event.target.value)" />
    <!-- 提交按钮 点击按钮触发父组件的submitTodo事件 -->
    <button class="todo-btn" @click="$emit('userEvent', {
        //定义一个事件类型便于父组件处理
        type: 'submitTodo',
        //事件详情 待办事项内容
        detail: modelValue,
    })">Submit</button>
  </div>
</template>
<script lang="ts" setup>
//接收父组件传递的modelValue
withDefaults(defineProps<{
  modelValue: string;
}>(),{
  modelValue: ''
})
const emits = defineEmits(['update:modelValue','userEvent'])
</script>
<style scoped>
.todo-msg {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.todo-input {
  flex: 1;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 0.25rem;
  margin-right: 0.5rem;
}
.todo-input:focus {
  outline: none;
  border-color: #007bff;
}
.todo-btn {
  min-width: 100px;
  height: 100%;
  padding: 0.5rem;
  border: none;
  border-radius: 0.25rem;
  background-color: #007bff;
  color: #fff;
  cursor: pointer;
}
</style>