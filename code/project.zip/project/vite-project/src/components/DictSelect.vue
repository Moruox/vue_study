<template>
  <el-tag type="primary" effect="dark" >{{label ? label : '无'}}</el-tag>
</template>
<script lang="ts" setup>
import { computed} from "vue";
import  {DictListType} from "../api/type";
//使用element-plus的Tag类型便于类型提示
import  {TagProps } from "element-plus";
type DictSelectProps = {
  selected: string,
  dictList: DictListType[]
} & Partial<TagProps>
//设置可以接收的参数
const props = withDefaults(defineProps<
  DictSelectProps>(), { //进行类型联合
  selected: '',
  dictList: [],
})
//根据value和dictList计算label
const label = computed(() => props.selected && props.dictList.find(item => item.value === props.selected)?.label || '')
</script>