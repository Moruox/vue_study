<template>
  <el-card v-loading="pageData.loading">
    <el-row align="middle" class="toolbar">
      <el-col :span="24">
        <el-button
            type="primary"
            @click="handleAddOrEdit(null)"
        >新增用户</el-button>
      </el-col>
    </el-row>
    <el-table :data="pageData.tableData" height="780px" border>
      <el-table-column prop="id" label="ID" ></el-table-column>
      <el-table-column prop="userName" label="用户名" ></el-table-column>
      <el-table-column prop="age" label="年龄" ></el-table-column>
      <el-table-column prop="post" label="岗位" >
        <template #default="scope">
          <DictSelect :selected="scope.row.postCode" :dict-list="post" />
        </template>
      </el-table-column>
      <el-table-column prop="gender" label="性别" >
        <template #default="scope">
          <DictSelect :selected="scope.row.gender" :dict-list="gender" />
        </template>
      </el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
      <el-table-column prop="email" label="邮箱"></el-table-column>
      <el-table-column label="操作" width="200px">
        <template #default="scope">
          <el-button link type="primary" @click="handleAddOrEdit(scope.row)">编辑</el-button>
          <el-button link type="primary" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-divider />
    <el-pagination
        v-model:current-page="pageData.currentPage"
        v-model:page-size="pageData.pageSize"
        @current-change="getUsers"
        @size-change="()=>{pageData.currentPage=1;getUsers()}"
        :page-sizes="pageData.pageSizes"
        :total="pageData.total"
        background
        layout="prev, pager, next,->,sizes,total,"
    ></el-pagination>
    <formDialog
        v-model="pageData.dialogVisible"
        :form-data="formData"
        :post-code-list="post"
        :gender-list="gender"
        @submit="handleSubmit"
    />
  </el-card>
</template>
<script lang="ts" setup>
import {onMounted, reactive} from "vue";
import formDialog from "./from.vue";
import DictSelect from "../../components/DictSelect.vue";
import type {User} from "../../api/type";
import {getUserListApi, getGenderDictApi, updateUserApi, addUserApi, deleteUserApi} from "../../api/user";
import {ElMessage} from "element-plus";
const { post, gender } = getGenderDictApi("post","gender")
//初始化表单数据
const initFormData = ()=>({
  id: "",
  userName: "",
  age: 0,
  gender: "1",
  email: "",
  password: "",
  address: "",
  postCode: "",
})
//表单数据(用于新增和编辑)
const formData = reactive(initFormData())
//页面数据(用于显示表格数据)
const pageData = reactive({
  tableData: [],//存放表格数据
  dialogVisible: false,//对话框是否可见
  currentPage: 1,//当前页面
  pageSize: 3,//每页显示条数
  pageSizes: [3, 5,7,10,20],//每页显示条数选项
  total: 0,//总条数
  loading: false,//页面的loading状态
})
//获取用户列表的方法
const getUsers = async () => {
  try {
    pageData.loading = true
    const result = await getUserListApi(pageData)
    pageData.tableData = result.data.list
    pageData.total = result.data.total
  }catch (error) {
    console.error(error)
  }finally {
    pageData.loading = false
  }
}
//新增用户或编辑用户打开对话框表单的方法
const handleAddOrEdit = (user?:User) => {
  //打开对话框
  pageData.dialogVisible = true
  //清空表单数据或填充表单数据(有用户则填充用户数据)
  if(user) {
    Object.assign(formData, user)
    return
  }
  //清空表单数据
  Object.assign(formData, initFormData())
}
//新增或编辑提交变更的方法
const handleSubmit = async (user:User) => {
  try {
    let result
    if(user.id){
      //编辑用户
     result = await updateUserApi(user)
    }else {
      //新增用户
     result = await addUserApi(formData)
    }
    ElMessage.success(result.message)
    await getUsers()
  }catch (error) {
    ElMessage.error(error.message)
  }finally {
    pageData.dialogVisible = false
  }
}
onMounted(()=>{
  getUsers()
})
//删除用户的方法
const handleDelete = async (user:User) => {
  try {
    const result = await deleteUserApi(user.id)
    ElMessage.success(result.message)
    await getUsers()
  } catch (error) {
    ElMessage.error(error.message)
  }
}
</script>
<style scoped>
.toolbar {
  padding: 5px 0 10px 0;
}
</style>