<template>
  <el-dialog :title="formData.id ? '编辑用户' : '新增用户'" :="attrs" align-center>
    <el-form label-width="60px" label-position="left">
      <el-row :gutter="40">
        <el-col :span="12">
          <el-form-item label="用户名">
            <el-input v-model="formData.userName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="密码">
            <el-input v-model="formData.password" type="password" show-password></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="性别">
            <el-radio-group v-model="formData.gender">
              <el-radio  v-for="item in genderList" :key="item.value" :value="item.value">{{item.label}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="年龄">
            <el-input-number v-model="formData.age"></el-input-number>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="岗位">
            <el-select v-model="formData.postCode" placeholder="请选择岗位">
              <el-option
                  v-for="item in postCodeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="邮箱">
            <el-input v-model="formData.email"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="地址">
            <el-input
                v-model="formData.address"
                type="textarea"
                maxlength="100"
                show-word-limit>
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-button type="primary" @click="submitForm">提交</el-button>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
<script lang="ts" setup>
import { reactive, ref , useAttrs } from "vue";
import type {DictListType, User} from "../../api/type";
const attrs = useAttrs();
const props = withDefaults(defineProps<{
  postCodeList: DictListType[]
  genderList: DictListType[]
  formData: User
}>(),{
  postCodeList: [],
  genderList: [],
  formData: {
    userName: "",
    password: "",
    email: "",
    gender: "1",
    age: 0,
    postCode: "",
    address: ""
  }
});
const emit = defineEmits(['submit'])
const submitForm = ()=>{
  emit('submit', props.formData)
}
</script>