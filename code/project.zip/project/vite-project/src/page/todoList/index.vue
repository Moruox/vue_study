<template>
  <div class="todo-container">
    <!--引入使用,并绑定数据，监听事件-->
    <TodoMsg v-model="state.todoMsg" @userEvent="userEvent"/>
    <ToDoList :todoList="state.todoList" @userEvent="userEvent"/>
  </div>
</template>
<script lang="ts" setup>
import TodoMsg from '../../components/todoMessageInput.vue'
import ToDoList from "../../components/todoList.vue";
import {onMounted, reactive} from 'vue'
import type {ToDoType} from "../../type/todoType.ts";
import {generateId} from "../../utils/generateId.ts";
import {deleteMessageApi, insertMessageApi, selectAllMessageApi, updateMessageApi} from "../../api/local_req.ts";
import {deleteMessage, updateMessage} from "../../db";
//定义数据源
const state = reactive<{
  todoMsg: string,
  todoList: Array<ToDoType>,
}> ({
  todoMsg: '',
  todoList: []
})
//完善业务逻辑处理
//添加todo触发的逻辑
const addTodo = (message: string) => {
  if (state.todoMsg.trim() === '') {
    return
  }
  const newTodo = {
    id: '',
    message: message,
    edit: false
  }
  const result = insertMessageApi(newTodo)
  if (result.code === 200) {
    getTodoList()
  }
  state.todoMsg = ''
}
//删除todo触发的逻辑
const deleteTodo = (id: number) => {
  const result = deleteMessageApi(id)
  if (result.code === 200) {
    getTodoList()
    }
}
//编辑todo触发的逻辑
const editTodo = (todo: ToDoType) => {
  const todoIndex = state.todoList.findIndex(item => item.id === todo.id)
  if (todoIndex !== -1) {
    todo.edit = !todo.edit
    if(todo.edit){
      state.todoList[todoIndex] = todo
    }else {
      const result = updateMessageApi(todo)
      if(result.code === 200){
        getTodoList()
      }
    }
  }
}
//用户事件
const userEvent = (emitEvent: { type: 'submitTodo' | 'deleteTodo', detail:ToDoType | string}) => {
//根据事件类型进行不同的处理
  switch (emitEvent.type) {
    case 'submitTodo':
      addTodo(emitEvent.detail as string)
      break
    case 'deleteTodo':
      deleteTodo((emitEvent.detail as ToDoType).id)
      break
    case 'editTodo':
      editTodo(emitEvent.detail)
      break
    default:
      break
  }
}
//发送请求获取最新的todoList列表的方法
const getTodoList = () => {
  //查询所有todoList
  const result = selectAllMessageApi()
  if (result.code === 200) {
    console.log(result.data.list)
    state.todoList = result.data.list
  }
}
onMounted(()=>{
  getTodoList()
})
</script>
<style lang="css" scoped>
.todo-container {
  width: 800px;
  margin: 0 auto;
  height: 100%;
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 4px;
}
</style>