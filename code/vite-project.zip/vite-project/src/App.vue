<template>
  <div class="todo-container">
    <!--引入使用,并绑定数据，监听事件-->
    <TodoMsg v-model="state.todoMsg" @userEvent="userEvent"/>
    <ToDoList :todoList="state.todoList" @userEvent="userEvent"/>
  </div>
</template>
<script lang="ts" setup>
import TodoMsg from './components/todoMessageInput.vue'
import ToDoList from "./components/todoList.vue";
import { reactive } from 'vue'
import type {ToDoType} from "./type/todoType.ts";
//定义数据源
const state = reactive<{
  todoMsg: string,
  todoList: Array<ToDoType>,
}> ({
  todoMsg: '',
  todoList: []
})
//完善业务逻辑处理
//生成唯一id的工具函数
const generateId = () => {
  return Math.random().toString(36).substr(2, 9)
}
//添加todo触发的逻辑
const addTodo = (message: string) => {
  if (state.todoMsg.trim() === '') {
    return
  }
  const newTodo = {
    id: generateId(),
    message: message,
    edit: false
  }
  state.todoList.push(newTodo)
  state.todoMsg = ''
}
//删除todo触发的逻辑
const deleteTodo = (todo: ToDoType) => {
  const index = state.todoList.findIndex(todo => todo.id === todo.id)
  if (index!== -1) {
    state.todoList.splice(index, 1)
  }
}
//编辑todo触发的逻辑
const editTodo = (todo: ToDoType) => {
  const todoIndex = state.todoList.findIndex(item => item.id === todo.id)
  if (todoIndex !== -1) {
    todo.edit = !todo.edit
    state.todoList[todoIndex] = todo
  }
}
//用户事件
const userEvent = (emitEvent: { type: 'submitTodo' | 'deleteTodo', detail:ToDoType | string}) => {
//根据事件类型进行不同的处理
  switch (emitEvent.type) {
    case 'submitTodo':
      addTodo(emitEvent.detail as string)
      break
    case 'deleteTodo':
      deleteTodo((emitEvent.detail as ToDoType).id)
      break
    case 'editTodo':
      editTodo(emitEvent.detail)
      break
    default:
      break
  }
}
</script>
<style lang="css" scoped>
.todo-container {
  width: 800px;
  margin: 0 auto;
  height: 100%;
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 4px;
}
</style>