<template>
  <div class="todo-list-container">
    <!--循环生成代办事项列表-->
    <div class="todo-list" v-for="todo in todoList" :key="todo.id">
      <!--如果开启编辑模式,则显示编辑框,否则显示待办事项内容-->
      <div v-if="!todo.edit" class="message">{{todo.message}}</div>
      <!--当输入框失去焦点时,触发submitEdit方法,通知父组件更新数据-->
      <input v-else type="text" class="edit-input" v-model="todo.message" @blur="submitEdit(todo)"/>
      <!--编辑按钮,点击按钮触发变更当前todo的edit状态-->
      <button v-if="!todo.edit" class="btn edit-btn" @click="emits('userEvent', {type: 'editTodo', detail: todo})">Edit</button>
      <!--删除按钮,点击按钮触发父组件的deleteTodo事件-->
      <button class="btn remove-btn" @click="emits('userEvent', {type: 'deleteTodo', detail: todo})">Remove</button>
    </div>
  </div>
</template>
<script lang="ts" setup>
//定义接收父组件的参数
import type {ToDoType} from "../type/todoType.ts";

const props = withDefaults(defineProps<{
  todoList: {
    id:string,
    message:string,
  }[]
}>(),{
  //用于渲染初始数据
  todoList: []
})
//定义子组件触发的事件
const emits = defineEmits(['userEvent','update:todoList'])
//当编辑完成后，将编辑的结果通知父组件
const submitEdit = (todo: ToDoType) => {
  emits('userEvent', {type: 'editTodo', detail: todo})
}
</script>
<!-- 样式 -->
<style scoped>
.todo-list-container{
  margin-top: 20px;
  width: calc(100% - 10px);
  height: 400px;
  overflow-y: scroll;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 5px;
}
.todo-list {
  width: calc(100% - 20px);
  display: flex;
  align-items: center;
  justify-content: center;
  height: 40px;
  border: 1px solid #ccc;
  margin: 10px 0;
  padding: 5px;
  font-size: 16px;
  color: #333;
}
.message {
  flex: 1;
}
.edit-input {
  flex: 1;
  height: 30px;
  margin-right: 0.5rem;
  border-radius: 0.25rem;
  border: 1px solid #ccc;
}
.edit-input:focus {
  outline: none;
  border-color: #007bff;
}
.btn {
  min-width: 100px;
  padding: 0.14rem;
  height: 30px;
  border: none;
  border-radius: 0.25rem;
  color: #fff;
  cursor: pointer;
  margin-right: 0.5rem;
}
.remove-btn {
  background-color: #dc3545;
}
.edit-btn {
  background-color: #007bff;
}
</style>