export type ToDoType = {
    id: string
    message: string
    edit: boolean
}